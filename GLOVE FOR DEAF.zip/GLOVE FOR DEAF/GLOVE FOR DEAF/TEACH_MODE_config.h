#ifndef _APP_TEACH_MODE_CONFIG_H_
#define _APP_TEACH_MODE_CONFIG_H_
#endif