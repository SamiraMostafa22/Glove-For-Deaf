#include "types.h"
#include "bitmath.h"
#include "DIO_interface.h"
#include "ADC_interface.h"
#include "ADC_config.h"
#include "ADC_private.h"
#include "avr/interrupt.h"

static void (*ADC_CallBack)(void) = 0;

void ADC_vidInit(_enuADCCHANNELS enuADCChannel)
{
    //enables the SREG Interrupt bit
     sei();
    ADMUX &= 0xE0; // Bitmask
    switch (enuADCChannel)
    {
    case ADC_CH0:
        //Sets the Said Channel Pin Direction as Input
        DIO_vidSetPinMode(GPIOA, PIN, INPUT);
        //bitmath to set the channel bit to one
        ADMUX |= ADC_CH0;
        break;
    case ADC_CH1:
        DIO_vidSetPinMode(GPIOA, PIN1, INPUT);
        ADMUX |= ADC_CH1;
        break;
    case ADC_CH2:
        DIO_vidSetPinMode(GPIOA, PIN2, INPUT);
        ADMUX |= ADC_CH2;
        break;
    case ADC_CH3:
        DIO_vidSetPinMode(GPIOA, PIN3, INPUT);
        ADMUX |= ADC_CH3;
        break;
    case ADC_CH4:
        DIO_vidSetPinMode(GPIOA, PIN4, INPUT);
        ADMUX |= ADC_CH4;
        break;
    case ADC_CH5:
        DIO_vidSetPinMode(GPIOA, PIN5, INPUT);
        ADMUX |= ADC_CH5;
        break;
    case ADC_CH6:
        DIO_vidSetPinMode(GPIOA, PIN6, INPUT);
        ADMUX |= ADC_CH6;
        break;
    case ADC_CH7:
        DIO_vidSetPinMode(GPIOA, PIN7, INPUT);
        ADMUX |= ADC_CH7;
        break;
    default:
        break;
    }

    ADCSRA &= 0xF8;    // Bitmask
    ADCSRA |= ADC_PSC; // Prescaler

    ADMUX &= 0x3F; // Bitmask
    ADMUX |= (ADC_VREF << 6); //Setting VREF

#if ADC_STORE == 0 // Right adjust
    CLR_BIT(ADMUX, ADLAR);
#else
    SET_BIT(ADMUX, ADLAR); //left adjust
#endif
   //activating adc by ADC ENABLE
    SET_BIT(ADCSRA, ADEN);
    //the ADC Conversion Complete Interrupt is activated
    SET_BIT(ADCSRA, ADIE);
    //setting the Auto Trigger Enable
    SET_BIT(ADCSRA, ADATE);
}


void ADC_StartConversion()
{

    // 1- Activate Start of Conversion
    SET_BIT(ADCSRA, ADSC);
    // 2- Wait until conversion Ended (polling)
    while (GET_BIT(ADCSRA, ADIF) == 0) ;
    // 3- Clear Interrupt Flag after Ended
    SET_BIT(ADCSRA, ADIF);
}


u16 ADC_u16Read(_enuADCCHANNELS enuADCChannel)
{
    u16 u16ReturnedValue;
    // Set input channel to read
    ADMUX = ADMUX | (enuADCChannel & 0x0F);
    // 4- Read ADCL then ADCH in order
    u16ReturnedValue = (u16)ADCL;
    u16ReturnedValue |= (u16)(ADCH << 8);
    return u16ReturnedValue;
}

void ADC_vidSetCallBack(void(*copy_PF)(void))
{
    ADC_CallBack=copy_PF;
}

ISR(ADC_vect)
{
    ADC_CallBack();
}
