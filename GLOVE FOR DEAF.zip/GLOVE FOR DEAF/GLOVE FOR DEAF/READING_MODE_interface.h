#ifndef _APP_READING_MODE_INTERFACE_H_
#define _APP_READING_MODE_INTERFACE_H_


   void Reading_Mode_vidInit();
   void Reading_Mode_vidCompareReadings();

#endif