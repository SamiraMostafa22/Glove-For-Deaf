#ifndef _HAL_FLEX_SENSOR_CONFIG_H_
#define _HAL_FLEX_SENSOR_CONFIG_H_

#define thumb  ADC_CH0
#define index  ADC_CH2
#define middle ADC_CH3
#define ring   ADC_CH4
#define pinky  ADC_CH5

#endif
