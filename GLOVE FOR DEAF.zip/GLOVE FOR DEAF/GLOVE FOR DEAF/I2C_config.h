#ifndef _MCAL_I2C_CONFIG_H_
#define _MCAL_I2C_CONFIG_H_
#endif