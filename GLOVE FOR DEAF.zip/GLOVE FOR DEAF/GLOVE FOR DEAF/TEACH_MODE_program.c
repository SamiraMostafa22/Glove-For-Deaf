#include "types.h"
#include "bitmath.h"
#include "FLEX_SENSOR_INTERFACE.H"
#include "EEPROM_EXTERNAL_interface.h"
#include "TEACH_MODE_interface.h"

void TEACH_vidInit()
{
    EEPROM_init();
}


void TEACH_vidmemory()
{
   	for(u8 i=114 ; i<115 ;i++)
	{
		EEPROM_WriteData(i,'\0');
		_delay_ms(100);
	}
	EEPROM_WriteArray(0,"I'mWatchingYou\0");
	EEPROM_WriteArray(16,"You\0");
	EEPROM_WriteArray(225,"ReallyILoveYou");
	EEPROM_WriteArray(34,"ILOVEYOU\0");
	EEPROM_WriteArray(240,"ThisIsTerrible\0");
	EEPROM_WriteArray(56,"GoodJob\0");
	EEPROM_WriteArray(64,"OK");
	EEPROM_WriteArray(67,"I'mNotSure");
	EEPROM_WriteArray(117,"Question");
	EEPROM_WriteArray(87,"Welcome");
	EEPROM_WriteArray(96,"GoodBye");
	EEPROM_WriteArray(105,"I");
	EEPROM_WriteArray(108,"W");
	EEPROM_WriteArray(111,"L");
	EEPROM_WriteArray(114,"7");
}