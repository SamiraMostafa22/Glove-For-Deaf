/*
 * GLOVE FOR DEAF.c
 *
 * Created: 2/16/2023 5:49:36 PM
 * Author : SHAHD RIAD
 */ 

#include "types.h"
#include "bitmath.h"
#include "READING_MODE_interface.h"


#define F_CPU   8000000UL
#include "util/delay.h"


int main(void)
{
	Reading_Mode_vidInit();
    /* Replace with your application code */
    while (1) 
    {
		Reading_Mode_vidCompareReadings();
    }
}

