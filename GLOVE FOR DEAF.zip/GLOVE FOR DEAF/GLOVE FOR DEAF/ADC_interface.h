#ifndef _MCAL_ADC_INTERFACE_H_
#define _MCAL_ADC_INTERFACE_H_

typedef enum
{
   ADC_CH0=0,
   ADC_CH1,
   ADC_CH2,
   ADC_CH3,
   ADC_CH4,
   ADC_CH5,
   ADC_CH6,
   ADC_CH7
 
} _enuADCCHANNELS;

void ADC_vidInit(_enuADCCHANNELS enuADCChannel);
void ADC_StartConversion();
u16 ADC_u16Read(_enuADCCHANNELS enuADCCHANNEL);


#endif