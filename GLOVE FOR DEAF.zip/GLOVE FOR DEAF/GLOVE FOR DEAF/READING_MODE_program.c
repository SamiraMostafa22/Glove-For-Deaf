#include "types.h"
#include "bitmath.h"
#include "LCD_interface.h"
#include "FLEX_SENSOR_interface.h"
#include "EEPROM_EXTERNAL_interface.h"
#include <avr/delay.h>

//straight angle 480:580 (580>)
// bend angle 580:700 (580<)

u8 ARRAY[16]; //word storing
extern u16 thumb_read ,index_read,middle_read,ring_read,pinky_read ; //the reading from the flex read function

void Clean_Array(u8 Array[])
{
	for(u8 i=0 ; i<16 ;i++)
		{
			Array[i]='\0';
		}
}

void Reading_Mode_vidInit()
{
    //initiating the sensors & other peripherals
    FLEX_vidInit();
    EEPROM_init();
    LCD_vidInit();
    LCD_vidClearScreen();
}

void Reading_Mode_vidCompareReadings()
{
    //1 WELCOME
    if (thumb_read<=580 && index_read<=580 && middle_read<=580 &&ring_read<=580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(87 , ARRAY); //Call String Which Starts for Location 87 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD WELCOME
        //displays the same word as long as the readings don't change
        while (thumb_read<=580 && index_read<=580 && middle_read<=580 &&ring_read<=580 && pinky_read<=580);    
    }

     //2 ILOVEYOU
   else if (thumb_read<=580 && index_read<=580 && middle_read>580 && ring_read>580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(34 , ARRAY); //Call String Which Starts for Location 34 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD ILOVEYOU
        //displays the same word as long as the readings don't change
        while (thumb_read<=580 && index_read<=580 && middle_read>580 && ring_read>580 && pinky_read<=580);    
    }
    //3 IMWATCHINGYOU
 else if (thumb_read>580 && index_read<=580 && middle_read<=580 && ring_read>580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(0 , ARRAY); //Call String Which Starts for Location 0 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD IMWATCHINGYOU
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read<=580 && middle_read<=580 && ring_read>580 && pinky_read>580 );    
    }

      //4 I
 else if (thumb_read>580 && index_read>580 && middle_read>580 &&ring_read>580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(105 , ARRAY); //Call String Which Starts for Location 105 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS I
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read>580 && middle_read>580 &&ring_read>580 && pinky_read<=580 );    
    }

     //5 YOU
 else if (thumb_read>580 && index_read<=580 && middle_read>580 &&ring_read>580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(16 , ARRAY); //Call String Which Starts for Location 16 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD YOU
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read<=580 && middle_read>580 &&ring_read>580 && pinky_read>580 );    
    }

     //6 THISISTERRIBLE
 else if (thumb_read>580 && index_read<=580 && middle_read>580&& ring_read>580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(240, ARRAY); //Call String Which Starts for Location 240 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD THISISTERRIBLE
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read<=580 && middle_read>580&& ring_read>580 && pinky_read<=580 );    
    } 
  

     //7 GOOD JOB
 else if (thumb_read<=580 && index_read>580 && middle_read>580&& ring_read>580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(56, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD GOOD JOB
        //displays the same word as long as the readings don't change
        while (thumb_read<=580 && index_read>580 && middle_read>580&& ring_read>580 && pinky_read>580 );    
    } 


  //8 REALLYILOVEYOU
 else if (thumb_read<=580 && index_read<=590 && middle_read<=580 &&ring_read>580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(225, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD REALLYILOVEYOU
        //displays the same word as long as the readings don't change
        while (thumb_read<=580 && index_read<=590 && middle_read<=580 &&ring_read>580 && pinky_read<=580 );    
    } 

    //9 OK
 else if (thumb_read>580 && index_read>580 && middle_read<=580 &&ring_read<=580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(64, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD OK
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read>580 && middle_read<=580 &&ring_read<=580 && pinky_read<=580 );    
    } 

  //10 I'MNOTSURE
 else if (thumb_read<=580 && index_read>580 && middle_read>580 &&ring_read>580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(67, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD I'MNOTSURE
        //displays the same word as long as the readings don't change
        while (thumb_read<=580 && index_read>580 && middle_read>580 &&ring_read>580 && pinky_read<=580  );    
    } 

    //11 L
 else if (thumb_read<=580 && index_read<=580 && middle_read>580 &&ring_read>580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(111, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD L
        //displays the same word as long as the readings don't change
        while (thumb_read<=580 && index_read<=580 && middle_read>580 &&ring_read>580 && pinky_read>580 );    
    } 

      //12 7
 else if (thumb_read>580 && index_read<=580 && middle_read<=580&& ring_read>580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(114, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD 7
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read<=580 && middle_read<=580&& ring_read>580 && pinky_read>580 );    
    } 

    
      //13 W
 else if (thumb_read>580 && index_read<=580 && middle_read<=580 &&ring_read<=580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(108, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD W
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read<=580 && middle_read<=580&& ring_read<=580 && pinky_read>580  );    
    } 

      //14 QUESTION
 else if (thumb_read>580 && index_read>580 && middle_read>580&& ring_read>580 && pinky_read>580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(117, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD QUESTION
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read>580 && middle_read>580 &&ring_read>580 && pinky_read>580 );    
    } 

   //15 GOODBYE
 else if (thumb_read>580 && index_read<=580 && middle_read<=580&& ring_read<=580 && pinky_read<=580 )
    {
        Clean_Array(ARRAY); //cleans the array of chars
        LCD_vidClearScreen(); //clears lcd
        EEPROM_WriteArray(96, ARRAY); //Call String Which Starts for Location 56 in Memory
        LCD_vidMoveCursor(1,1); //STARTS WRITING ON THE FIRST LINE IN THE FIRST DIGIT
        LCD_vidDisplayString(ARRAY); //DISPLAYS THE WORD GOODBYE
        //displays the same word as long as the readings don't change
        while (thumb_read>580 && index_read<=580 && middle_read<=580&& ring_read<=580 && pinky_read<=580 );    
    } 
   else{}

}