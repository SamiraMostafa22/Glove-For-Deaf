#ifndef _HAL_EXTERNAL_EEPROM_INTERFACE_H_
#define _HAL_EXTERNAL_EEPROM_INTERFACE_H_

void EEPROM_init(void);
void EEPROM_WriteData(u8 address_inBlock,u8 Data);
u8 EEPROM_ReadData(u8 address_inBlock);
void EEPROM_WriteArray(u8 address_inBlock,u8 * Data);
void EEPROM_ReadArray(u8 address_inBlock , u8 * Data);

#endif