#include "types.h"
#include "bitmath.h"
#include "DIO_interface.h"

#include "I2C_private.h"
#include "I2C_interface.h"

void I2C_InitMaster(void)
{
	//Clock Factor
	TWBR=12;

	//Prescaler
	CLR_BIT(TWSR,0); 
	CLR_BIT(TWSR,1);

	//Enable ACK
	SET_BIT(TWCR,6);

	//Enable I2C
	SET_BIT(TWCR,2);


}
void I2C_InitSlave(void)
{
	//Set Slave Address
	TWAR=0x20;

	//Enable ACK
	SET_BIT(TWCR,6);
    //Enable I2C
	SET_BIT(TWCR,2);
}
void I2C_start(void)
{
	// Send Start Condition
	SET_BIT(TWCR,5);
	
	// Clear flag to start current job
	SET_BIT(TWCR,7);
	
	//Wait For Flag
	while(GET_BIT(TWCR,7)!=1);

	//State start is ok
	while((TWSR & 0xF8)!=0x08);
}

void I2C_RepeatedStart(void)
{
	// Send Start Condition
	SET_BIT(TWCR,5);
	
	// Clear flag to start current job
	SET_BIT(TWCR,7);
	//Wait For Flage
	while(GET_BIT(TWCR,7)!=1);

	//State Re_start is ok
	while((TWSR & 0xF8)!=0x10);
}
void I2C_stop(void)
{
	// Send Stop Condition
	SET_BIT(TWCR,4);
	
	// Clear flag to start current job
	SET_BIT(TWCR,7);
}
void I2C_SendSlaveAddress_Write(u8 Slave_Address)
{
	// Send slave address
	TWDR = Slave_Address<<1;
	
	// Select write operation
	CLR_BIT(TWDR,0);
	
	// Clear SC bit
	CLR_BIT(TWCR,5);
	
	// Clear flag to start current job
	SET_BIT(TWCR,7);
	
	// Wait for the flag
	while(0 == GET_BIT(TWCR,7));
	
	// Check ACK = Master transmit ( slave address + Write request ) ACK
	while((TWSR & 0xF8) != 0x18);
}
void I2C_SendSlaveAddress_Read(u8 Slave_Address)
{
	// Send slave address
	TWDR = Slave_Address<<1;
	
	// Select read operation
	SET_BIT(TWDR,0);
	
	// Clear SC bit
	CLR_BIT(TWCR,5);
	
	// Clear flag to start current job
	SET_BIT(TWCR,7);
	
	// Wait for the flag
	while(0 == GET_BIT(TWCR,7));
	
	// Check ACK = Master transmit ( slave address + Read request ) ACK
	while((TWSR & 0xF8) != 0x40);
}
void I2C_WriteByte(u8 Data)
{
	//Load Data
	TWDR=Data;

	//Clear Flag
	//TWI Enable Bit
	TWCR = (1<<7)|(1<<2);

	//Wait For Flage
	while(GET_BIT(TWCR,7)!=1);

	//ACK Check
	while((TWSR & 0xF8)!=0x28);
}
u8 I2C_ReadByte(void)
{
	//Clear Flag
	//TWI Enable Bit
	TWCR = (1<<7)|(1<<2);

	//Wait For Flage
	while(GET_BIT(TWCR,7)!=1);

	//ACK Check
	while((TWSR & 0xF8)!=0x58);

	//Get Data
	return TWDR;
}
