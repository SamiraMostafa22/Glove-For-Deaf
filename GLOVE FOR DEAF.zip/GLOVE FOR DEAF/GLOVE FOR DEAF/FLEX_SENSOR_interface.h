#ifndef _HAL_FLEX_SENSOR_INTERFACE_H_
#define _HAL_FLEX_SENSOR_INTERFACE_H_
#include "ADC_interface.h"

void FLEX_vidInit ();
void FLEX_u16Read (); 

#endif