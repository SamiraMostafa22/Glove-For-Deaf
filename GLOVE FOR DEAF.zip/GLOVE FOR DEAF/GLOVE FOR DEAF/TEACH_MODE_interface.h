#ifndef _APP_TEACH_MODE_INTERFACE_H_
#define _APP_TEACH_MODE_INTERFACE_H_

void TEACH_vidInit();
void TEACH_vidmemory();
void Clean_Array(u8 Array[]);

#endif