#include "types.h"
#include "bitmath.h"
#include "DIO_interface.h"
#include "I2C_interface.h"

#include "EEEPROM_EXTERNAL_config.h"
#include "EEPROM_EXTERNAL_interface.h"
#include <avr/delay.h>



// The last bit indicates whether the memory operation will be a read or write. (0 for Writing)

void EEPROM_init(void)
{
	I2C_InitMaster(); 
	_delay_ms(100); 
}
void EEPROM_WriteData(u8 address_inBlock,u8 Data)
{
    // take control of the I2C bus.
	I2C_start();
    // Send the slave address of the EEPROM. Which is constructed as below:
   // The first 4 bits of the address are 1010
  // The next 3 bits represent the memory page number.
	I2C_SendSlaveAddress_Write(0xA0);
	I2C_WriteByte(address_inBlock);
	I2C_WriteByte(Data);
	I2C_stop();
}
u8 EEPROM_ReadData(u8 address_inBlock)
{
	u8 Data=0;
//	I2C_start();
//	I2C_SendSlaveAddress_Write(0xA0);
//	I2C_WriteByte(address_inBlock);
//	I2C_stop();
	I2C_start();
	I2C_SendSlaveAddress_Read(0xA1);
	Data=I2C_ReadByte();
	I2C_stop();
	return Data;
}
void EEPROM_WriteArray(u8 address_inBlock,u8 * Data)
{
	u8 i = 0;
	I2C_start();
	I2C_SendSlaveAddress_Write(0xa0);
	I2C_WriteByte(address_inBlock);
	while(Data[i] != '\0')
	{
		I2C_WriteByte(Data[i]);
		_delay_ms(100);
		i++;
	}
	I2C_WriteByte('\0');
	_delay_ms(100);
	I2C_stop();
	_delay_ms(100);
}
void EEPROM_ReadArray(u8 address_inBlock , u8 * Data)
{
	u8 i = 0;
	do
	{
		Data[i]=EEPROM_ReadData(address_inBlock+i);
		_delay_ms(100);
		i++;
	}while(Data[i-1] != '\0');
	Data[i]='\0';
	_delay_ms(100);
 }

