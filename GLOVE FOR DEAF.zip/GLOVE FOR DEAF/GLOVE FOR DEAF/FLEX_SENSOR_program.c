#include "Types.h"
#include "bitmath.h"
#include "DIO_interface.h"
#include "ADC_interface.h"

#include "FLEX_SENSOR_config.h"
#include "FLEX_SENSOR_private.h"
#include "FLEX_SENSOR_interface.h"


#define F_CPU  8000000UL
//#include "util/delay.h"

u16 thumb_read ,index_read,middle_read,ring_read,pinky_read ;

void FLEX_vidInit ()
{ 
	//initiates the said channels
   ADC_vidInit(thumb);
    ADC_vidInit(index);
	 ADC_vidInit(middle);
	  ADC_vidInit(ring);
	   ADC_vidInit(pinky);
}

void FLEX_u16Read()
{
	//reads from each channel and stores the reading in variables one for each finger
     thumb_read= ADC_u16Read(thumb);
	 index_read= ADC_u16Read(index);
	 middle_read= ADC_u16Read(middle);
	 ring_read= ADC_u16Read(ring);
	 pinky_read= ADC_u16Read(pinky);
}


